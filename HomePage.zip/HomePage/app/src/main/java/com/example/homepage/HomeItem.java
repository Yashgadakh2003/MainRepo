// HomeItem.java
package com.example.gridhomepage;

public class HomeItem {
    private String title;
    private int imageRes;

    public HomeItem(String title, int imageRes) {
        this.title = title;
        this.imageRes = imageRes;
    }

    public String getTitle() {
        return title;
    }

    public int getImageRes() {
        return imageRes;
    }
}
