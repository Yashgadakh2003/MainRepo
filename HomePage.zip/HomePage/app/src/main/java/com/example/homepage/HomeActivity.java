// HomeActivity.java
package com.example.homepage;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<com.example.gridhomepage.HomeItem> items;
    HomeAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        recyclerView = findViewById(R.id.recyclerView);
        items = new ArrayList<>();

        // Add items
        items.add(new com.example.gridhomepage.HomeItem("Alarm", R.drawable.alarm));
        items.add(new com.example.gridhomepage.HomeItem("Android", R.drawable.android));
        items.add(new com.example.gridhomepage.HomeItem("App", R.drawable.baseline_apps_24));
        items.add(new com.example.gridhomepage.HomeItem("Calllog", R.drawable.calllog));
        items.add(new com.example.gridhomepage.HomeItem("Settings", R.drawable.settings));


        adapter = new HomeAdapter(this, items, item ->
                Toast.makeText(HomeActivity.this, "Clicked: " + item.getTitle(), Toast.LENGTH_SHORT).show()
        );

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2)); // 2 columns
        recyclerView.setAdapter(adapter);
    }
}
